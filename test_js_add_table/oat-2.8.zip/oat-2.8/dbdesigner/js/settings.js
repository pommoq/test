/*
 *  $Id: settings.js,v 1.1 2008/01/30 11:35:17 source Exp $
 *
 *  This file is part of the OpenLink Software Ajax Toolkit (OAT) project.
 *
 *  Copyright (C) 2005-2007 OpenLink Software
 *
 *  See LICENSE file for details.
 */
var DELAY = 10; /* pauza mezi rostouci animaci */
var BAR_HEIGHT = 100;
