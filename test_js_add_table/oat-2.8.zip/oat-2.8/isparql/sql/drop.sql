--
--  $Id: drop.sql,v 1.1 2007/06/26 20:15:57 source Exp $
--
--  This file is part of the OpenLink Software Ajax Toolkit (OAT) project.
--
--  Copyright (C) 2007 OpenLink Software
--
--  See LICENSE file for details.
--

drop trigger WS.WS.ISPARQL_SYS_DAV_RES_I;

drop procedure WS.WS.__http_handler_isparql;
